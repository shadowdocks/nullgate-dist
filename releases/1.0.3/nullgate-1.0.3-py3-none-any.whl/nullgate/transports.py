"""Transport mechanisms and process orchestration for Nullgate.

Supports Upterm (default), srv.us reverse tunnels, Cloudflare Worker relays,
and Cloudflare Argo (cloudflared) tunnels.
"""

from __future__ import annotations

import base64
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from nullgate import bridge, client_config, gateway, ingress, wsroute
from nullgate.account import ensure_username_environment
import nullgate.runtime as st

DEFAULT_TRANSPORT = "upterm"
VALID_TRANSPORTS = ("upterm", "srvus", "cloudflare", "cloudflared")

_PKG_SRC = str(Path(__file__).resolve().parent.parent)


@dataclass
class Target:
    """Remote endpoint and SSH command details for an active transport."""

    host: str
    proxy_command: str
    setup_host: str
    url: str
    note: str = ""
    user: str = ""


def _spawn(command: list[str], environment: dict[str, str], log: Path) -> subprocess.Popen:
    pythonpath = _PKG_SRC
    if environment.get("PYTHONPATH"):
        pythonpath = f"{_PKG_SRC}{os.pathsep}{environment['PYTHONPATH']}"
    environment = {**environment, "PYTHONPATH": pythonpath}
    with open(log, "ab") as output:
        return subprocess.Popen(
            command,
            env=environment,
            stdout=output,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
        )


def normalize_endpoint(value: str, scheme: str) -> str | None:
    stripped = value.strip().rstrip("/")
    for prefix in ("https://", "http://", "wss://", "ws://"):
        if stripped.startswith(prefix):
            stripped = stripped[len(prefix) :]
            break
    if not stripped:
        return None
    return f"{scheme}://{stripped}"


def prepare_ssh_dir(ssh_dir: Path | None = None) -> bool:
    target = ssh_dir if ssh_dir is not None else Path(os.path.expanduser("~/.ssh"))
    try:
        target.mkdir(parents=True, exist_ok=True)
        target.chmod(0o700)
        return True
    except OSError:
        return False


def validate_ssh_public_key(path: Path) -> bool:
    ssh_keygen = shutil.which("ssh-keygen")
    if ssh_keygen:
        try:
            return (
                subprocess.run(
                    [ssh_keygen, "-l", "-f", str(path)],
                    capture_output=True,
                ).returncode
                == 0
            )
        except OSError:
            return False
    try:
        parts = path.read_text().split()
        if len(parts) < 2:
            return False
        blob = base64.b64decode(parts[1], validate=True)
        size = struct.unpack(">I", blob[:4])[0]
        return blob[4 : 4 + size].decode() == parts[0]
    except Exception:
        return False


def prompt_authorized_key() -> None:
    """Prompt user for SSH public key if none exists on standard input / tty."""
    keys = Path(os.path.expanduser("~/.ssh/authorized_keys"))
    if keys.is_file() and keys.stat().st_size > 0:
        return
    source = None
    if not sys.stdin.isatty():
        try:
            source = open("/dev/tty", "r")
        except OSError:
            return
    print("No SSH keys detected in ~/.ssh/authorized_keys.", file=sys.stderr)
    print(
        "Paste an OpenSSH public key for key-based authentication (or Enter to skip): ",
        file=sys.stderr,
        end="",
        flush=True,
    )
    pasted = (source or sys.stdin).readline().strip()
    if source is not None:
        source.close()
    if not pasted:
        print("Key entry skipped; relying on password authentication.", file=sys.stderr)
        return
    ssh_dir = Path(os.path.expanduser("~/.ssh"))
    if not prepare_ssh_dir(ssh_dir):
        print(f"Failed to prepare directory {ssh_dir}; skipped.", file=sys.stderr)
        return
    with tempfile.NamedTemporaryFile(
        prefix="nullgate-key.", dir=str(ssh_dir), mode="w"
    ) as temp:
        temp.write(pasted + "\n")
        temp.flush()
        if validate_ssh_public_key(Path(temp.name)):
            with open(keys, "ab") as output:
                output.write(pasted.encode() + b"\n")
            keys.chmod(0o600)
            print(f"Appended key to {keys}.", file=sys.stderr)
        else:
            print("Invalid SSH public key format; entry skipped.", file=sys.stderr)


def launch_gateway(
    transport: str,
    root: Path,
    port: int,
    password: str,
    accept: bool,
    allow_tcp_forwarding: bool,
    state: Path,
) -> subprocess.Popen:
    """Spawn the background gateway AsyncSSH daemon."""
    username = ensure_username_environment()
    flags = []
    if accept:
        flags.append("--accept")
    if allow_tcp_forwarding:
        flags.append("--allow-tcp-forwarding")
    if transport == "upterm":
        flags.extend(
            ["--no-password", "--upterm-ca-keys", str(state / "upterm-ca-keys")]
        )
    command = [
        sys.executable,
        "-m",
        "nullgate.gateway",
        "--root",
        str(root),
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--username",
        username,
        *flags,
    ]
    environment = {
        **os.environ,
        "NULLGATE_PASSWORD": password,
        "USER": username,
        "LOGNAME": username,
    }
    return _spawn(command, environment, state / "gateway.log")


def launch_transport_srvus(port: int, slot: int, state: Path) -> subprocess.Popen:
    ssh_dir = Path(os.path.expanduser("~/.ssh"))
    if not prepare_ssh_dir(ssh_dir):
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Failed to initialize SSH directory: {ssh_dir}")
    key = Path(os.path.expanduser("~/.ssh/id_ed25519"))
    st.repair_key_permissions(key)
    host = os.environ.get("NULLGATE_TUNNEL_HOST", "srv.us")
    try:
        sink_port = int(os.environ.get("NULLGATE_TUNNEL_PORT", "22"))
    except ValueError:
        sink_port = 22
    command = [
        sys.executable,
        "-m",
        "nullgate.ingress",
        "--host",
        host,
        "--port",
        str(sink_port),
        "--local-port",
        str(port),
        "--slot",
        str(slot),
        "--key",
        str(key),
    ]
    return _spawn(command, os.environ, state / "transport.log")


def launch_transport_cloudflare(
    endpoint: str, session: str, port: int, state: Path
) -> subprocess.Popen:
    if not endpoint:
        st.stop_one(state / "gateway.pid")
        raise SystemExit("The --endpoint option is required for the cloudflare transport")
    wss = normalize_endpoint(endpoint, "wss")
    if wss is None:
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Malformed endpoint URL: {endpoint}")
    base_url = f"{wss}/relay/{session}"
    command = [
        sys.executable,
        "-m",
        "nullgate.bridge",
        "origin",
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        base_url,
    ]
    return _spawn(command, os.environ, state / "transport.log")


def launch_transport_cloudflared(
    hostname: str, token: str, state: Path
) -> subprocess.Popen:
    if not shutil.which("cloudflared"):
        st.stop_one(state / "gateway.pid")
        raise SystemExit("cloudflared executable not found in PATH")
    if not hostname:
        st.stop_one(state / "gateway.pid")
        raise SystemExit("--hostname must be specified for cloudflared transport")
    tunnel_token = token or os.environ.get("NULLGATE_CLOUDFLARED_TOKEN", "")
    if not tunnel_token:
        st.stop_one(state / "gateway.pid")
        raise SystemExit(
            "A tunnel token must be supplied via --token or NULLGATE_CLOUDFLARED_TOKEN"
        )
    environment = {**os.environ, "TUNNEL_TOKEN": tunnel_token}
    return _spawn(["cloudflared", "tunnel", "run"], environment, state / "transport.log")


def launch_transport_upterm(
    endpoint: str | None, accept: bool, port: int, state: Path
) -> subprocess.Popen:
    ssh_dir = Path(os.path.expanduser("~/.ssh"))
    if not prepare_ssh_dir(ssh_dir):
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Failed to initialize SSH directory: {ssh_dir}")
    key = Path(os.path.expanduser("~/.ssh/id_ed25519"))
    st.repair_key_permissions(key)
    wss_endpoint = normalize_endpoint(endpoint or wsroute.DEFAULT_ENDPOINT, "wss")
    if wss_endpoint is None:
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Malformed endpoint URL: {endpoint}")
    command = [
        sys.executable,
        "-m",
        "nullgate.wsroute",
        "origin",
        "--endpoint",
        wss_endpoint,
        "--local-port",
        str(port),
        "--username",
        ensure_username_environment(),
        "--key",
        str(key),
        "--host-key",
        str(gateway.DEFAULT_HOST_KEY),
        "--authorized-keys",
        os.path.expanduser("~/.ssh/authorized_keys"),
        "--ca-keys",
        str(state / "upterm-ca-keys"),
        "--session-file",
        str(state / "upterm.json"),
    ]
    if accept:
        command.append("--accept")
    return _spawn(command, os.environ, state / "transport.log")


def launch_transport(
    transport: str,
    port: int,
    slot: int,
    session: str,
    state: Path,
    endpoint: str = "",
    hostname: str = "",
    token: str = "",
    accept: bool = False,
) -> subprocess.Popen:
    """Launch the chosen transport daemon."""
    if transport == "srvus":
        return launch_transport_srvus(port, slot, state)
    if transport == "cloudflare":
        return launch_transport_cloudflare(endpoint, session, port, state)
    if transport == "cloudflared":
        return launch_transport_cloudflared(hostname, token, state)
    return launch_transport_upterm(endpoint, accept, port, state)


def wait_for_srvus_host(transport_pid_file: Path, transport_log: Path) -> None:
    for _ in range(40):
        if not st.is_running(transport_pid_file):
            return
        if st.extract_host(transport_log):
            return
        time.sleep(0.5)


def wait_for_upterm_session(
    transport_pid_file: Path, session_file: Path
) -> dict[str, Any] | None:
    for _ in range(40):
        if not st.is_running(transport_pid_file):
            return None
        session = wsroute.read_session(session_file)
        if session:
            return session
        time.sleep(0.5)
    return None


def resolve_target(transport: str, state: Path) -> Target | None:
    """Resolve connection target details for the given transport."""
    if transport == "cloudflare":
        endpoint = st.manifest_get("endpoint")
        session = st.manifest_get("session")
        if not (endpoint and session):
            return None
        https = normalize_endpoint(endpoint, "https") or endpoint
        wss = normalize_endpoint(endpoint, "wss") or endpoint
        return Target(
            host="nullgate",
            proxy_command=f"nullgate proxy {wss}/relay/{session}",
            setup_host="nullgate",
            url=f"{https}/relay/{session}",
            note="Nullgate client must be installed on the connecting machine.",
        )
    if transport == "cloudflared":
        hostname = st.manifest_get("hostname")
        if not hostname:
            return None
        return Target(
            host=hostname,
            proxy_command="cloudflared access ssh --hostname %h",
            setup_host=hostname,
            url=f"ssh://{hostname}",
            note="cloudflared must be installed on the connecting machine.",
        )
    if transport == "upterm":
        session = wsroute.read_session(state / "upterm.json")
        if not session:
            return None
        endpoint = session["endpoint"]
        host = wsroute.endpoint_host(endpoint)
        proxy_url = wsroute.ssh_proxy_url(session)
        return Target(
            host=host,
            proxy_command=f"nullgate upterm-proxy {proxy_url}",
            setup_host=host,
            url=f"ssh://{session['ssh_user']}@{host}:443",
            note="Nullgate client must be installed on the connecting machine.",
            user=session["ssh_user"],
        )
    # srvus transport
    host = st.extract_host(state / "transport.log")
    if not host:
        return None
    return Target(
        host=host,
        proxy_command=client_config.SRVUS_PROXY_COMMAND,
        setup_host="*.srv.us",
        url=f"https://{host}/",
    )


def cmd_proxy(args: Any) -> int:
    return bridge.main(["client", args.url])


def cmd_upterm_proxy(args: Any) -> int:
    return wsroute.main(["client", args.url])
