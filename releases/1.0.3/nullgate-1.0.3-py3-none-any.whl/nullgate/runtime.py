"""Runtime state for the Nullgate CLI.

Owns the state directory, PID files (with process-identity protection against
recycled PIDs), credentials, manifest, session IDs, and key permissions.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

DEFAULT_PORT = 4822
SRVUS_HOST_RE = re.compile(r"https://([A-Za-z0-9.-]+\.srv\.us)/?")


def state_dir() -> Path:
    default = os.environ.get(
        "XDG_STATE_HOME",
        os.path.join(os.path.expanduser("~"), ".local", "state"),
    )
    return Path(os.environ.get("NULLGATE_STATE_DIR", default)) / "nullgate"


def setup_state() -> Path:
    """Create the state directory with owner-only access."""
    directory = state_dir()
    os.umask(0o077)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    directory.chmod(0o700)
    return directory


def process_identity(pid: int) -> str | None:
    """Hash an origin for ``pid`` so a recycled pid is never mistaken for ours.

    Uses /proc/PID/stat field 20 (starttime) when available, else the ps start
    time. Returns None when the pid cannot be inspected.
    """
    proc_stat = Path("/proc") / str(pid) / "stat"
    try:
        if proc_stat.is_file():
            data = proc_stat.read_text().rsplit(")", 1)[1].split()[19]
        else:
            data = subprocess.check_output(
                ["ps", "-p", str(pid), "-o", "lstart="], text=True
            ).strip()
    except (OSError, IndexError, subprocess.SubprocessError):
        return None
    if not data:
        return None
    return hashlib.sha256(data.encode()).hexdigest()


def read_pid(pid_file: Path) -> int | None:
    """Return the pid recorded in ``pid_file``, or None if malformed/absent."""
    with contextlib.suppress(OSError):
        fields = pid_file.read_text().split()
        if len(fields) == 2 and fields[0].isdigit():
            return int(fields[0])
    return None


def _identity_of(pid_file: Path) -> str | None:
    with contextlib.suppress(OSError):
        fields = pid_file.read_text().split()
        if len(fields) == 2:
            return fields[1]
    return None


def is_running(pid_file: Path) -> bool:
    """True when the recorded pid is alive and still matches its identity."""
    pid = read_pid(pid_file)
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    identity = process_identity(pid)
    return identity is not None and identity == _identity_of(pid_file)


def write_pid(pid_file: Path, pid: int) -> bool:
    """Record ``pid IDENTITY``; fails rather than track an unidentifiable pid."""
    identity = process_identity(pid)
    if identity is None:
        return False
    try:
        pid_file.write_text(f"{pid} {identity}\n")
    except OSError:
        return False
    return True


def kill_untracked(pid: int) -> None:
    """Stop a background process we cannot track via a pid file."""
    with contextlib.suppress(OSError):
        os.kill(pid, 15)
    for _ in range(50):
        try:
            os.kill(pid, 0)
        except OSError:
            break
        time.sleep(0.1)
    else:
        with contextlib.suppress(OSError):
            os.kill(pid, 9)


def stop_one(pid_file: Path) -> None:
    """Stop the process recorded in ``pid_file``, guarding against recycled pids."""
    pid = read_pid(pid_file)
    if pid is None:
        pid_file.unlink(missing_ok=True)
        return
    if is_running(pid_file):
        with contextlib.suppress(OSError):
            os.kill(pid, 15)
        for _ in range(50):
            if not is_running(pid_file):
                break
            time.sleep(0.1)
        else:
            with contextlib.suppress(OSError):
                os.kill(pid, 9)
    pid_file.unlink(missing_ok=True)


def port_open(port: int) -> bool:
    with contextlib.suppress(OSError):
        connection = socket.create_connection(("127.0.0.1", port), 0.2)
        connection.close()
        return True
    return False


def extract_host(transport_log: Path) -> str:
    """Return the last srv.us https host the transport log announced, if any."""
    try:
        text = transport_log.read_text(errors="replace")
    except OSError:
        return ""
    hosts = SRVUS_HOST_RE.findall(text)
    return hosts[-1] if hosts else ""


def generate_password() -> str:
    return secrets.token_urlsafe(32)


def get_or_create_session() -> str:
    """Reuse the persisted session id so the tunnel URL is stable across restarts."""
    session_file = state_dir() / "session"
    try:
        persisted = session_file.read_text().strip()
        if persisted:
            return persisted
    except OSError:
        pass
    session = secrets.token_urlsafe(24)
    session_file.write_text(session + "\n")
    return session


def manifest_get(key: str) -> str:
    """Read a field from manifest.json; return '' when missing."""
    manifest_file = state_dir() / "manifest.json"
    try:
        data = json.loads(manifest_file.read_text())
        if isinstance(data, dict):
            val = data.get(key, "")
            return str(val) if val is not None else ""
    except (OSError, json.JSONDecodeError):
        pass
    return ""


def write_manifest(entries: dict[str, Any]) -> None:
    """Record active session state in manifest.json."""
    directory = setup_state()
    manifest_file = directory / "manifest.json"
    manifest_file.write_text(json.dumps(entries, indent=2) + "\n")


def read_settings() -> dict[str, Any]:
    """Return parameters persisted in settings.json by the previous open command."""
    settings_file = state_dir() / "settings.json"
    try:
        data = json.loads(settings_file.read_text())
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return {}


def write_settings(entries: dict[str, Any]) -> None:
    """Persist parameters to settings.json with owner-only access permissions."""
    directory = setup_state()
    settings_file = directory / "settings.json"
    cleaned = {k: v for k, v in entries.items() if v is not None and v != ""}
    settings_file.write_text(json.dumps(cleaned, indent=2) + "\n")
    with contextlib.suppress(OSError):
        settings_file.chmod(0o600)


def repair_key_permissions(key: Path) -> None:
    """chmod an srv.us tunnel key to 0600, mirroring OpenSSH's restriction."""
    if not key.is_file():
        return
    mode = key.stat().st_mode & 0o777
    if mode == 0o600:
        return
    try:
        key.chmod(0o600)
    except OSError:
        print(
            f"Warning: could not fix permissions on {key} (mode {mode:03o})",
            file=sys.stderr,
        )
        return
    print(
        f"Fixed permissions on {key} (was {mode:03o}, now 600)",
        file=sys.stderr,
    )
