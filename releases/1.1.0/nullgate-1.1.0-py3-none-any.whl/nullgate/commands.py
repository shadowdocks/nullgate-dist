"""Command-line parser and entry point dispatch for Nullgate."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from nullgate import session, transports

SUBCOMMANDS = ("open", "shut", "inspect", "enter", "trace", "cycle", "upgrade")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nullgate",
        description="Disposable SSH gateway into confined directory workspaces.",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"nullgate {session._version()}",
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="command")

    open_parser = sub.add_parser(
        "open",
        description="Launch gateway daemon and ingress transport.",
    )
    open_parser.add_argument(
        "workspace",
        nargs="?",
        help="Directory exposed by the gateway (default: current directory).",
    )
    open_parser.add_argument(
        "--port",
        type=int,
        default=None,
        help=f"Local SSH listen port (default: {session.DEFAULT_PORT}).",
    )
    open_parser.add_argument(
        "--slot",
        type=int,
        default=None,
        help=f"Ingress slot number (default: {session.DEFAULT_SLOT}).",
    )
    open_parser.add_argument(
        "--transport",
        choices=transports.VALID_TRANSPORTS,
        default=None,
        help=f"Ingress transport provider (default {transports.DEFAULT_TRANSPORT}).",
    )
    open_parser.add_argument(
        "--accept",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Permit any client without credentials; --no-accept restores authentication.",
    )
    open_parser.add_argument(
        "--allow-tcp-forwarding",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Allow SSH port forwarding; use --no-allow-tcp-forwarding to disable it.",
    )
    open_parser.add_argument(
        "--confine-sftp",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Confine SFTP and SCP to the workspace; --no-confine-sftp restores host visibility.",
    )
    open_parser.add_argument(
        "--endpoint",
        help="WebSocket ingress endpoint URL (for upterm or cloudflare transports).",
    )
    open_parser.add_argument(
        "--hostname",
        help="Public hostname (for cloudflared transport).",
    )
    open_parser.add_argument(
        "--token",
        help="Cloudflare Argo tunnel token (for cloudflared transport).",
    )

    sub.add_parser(
        "shut",
        description="Halt running gateway and transport services.",
    )

    sub.add_parser(
        "inspect",
        description="Display service health, access URLs, and authentication status.",
    )

    sub.add_parser(
        "enter",
        description="Show SSH connection strings and client setup commands.",
    )

    trace_parser = sub.add_parser(
        "trace",
        description="View or stream service operational logs.",
    )
    trace_parser.add_argument(
        "target",
        nargs="?",
        default="all",
        choices=["all", "gateway", "transport"],
        help="Target log stream to inspect (default all).",
    )
    trace_parser.add_argument(
        "-f",
        "--follow",
        dest="f",
        action="store_true",
        help="Follow log stream output continuously.",
    )

    sub.add_parser(
        "cycle",
        description="Restart services using active or saved configuration.",
    )

    upgrade_parser = sub.add_parser(
        "upgrade",
        description="Fetch and install latest Nullgate release.",
    )
    upgrade_parser.add_argument(
        "--version",
        help="Install a specific published version instead of the latest stable release.",
    )

    proxy_parser = sub.add_parser(
        "proxy",
        description=argparse.SUPPRESS,
    )
    proxy_parser.add_argument("url")

    upterm_proxy = sub.add_parser(
        "upterm-proxy",
        description=argparse.SUPPRESS,
    )
    upterm_proxy.add_argument("url")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    handlers = {
        "open": session.cmd_open,
        "shut": session.cmd_shut,
        "inspect": session.cmd_inspect,
        "enter": session.cmd_enter,
        "trace": session.cmd_trace,
        "cycle": session.cmd_cycle,
        "upgrade": session.cmd_upgrade,
        "proxy": transports.cmd_proxy,
        "upterm-proxy": transports.cmd_upterm_proxy,
    }

    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help(sys.stderr)
        return 2
    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
