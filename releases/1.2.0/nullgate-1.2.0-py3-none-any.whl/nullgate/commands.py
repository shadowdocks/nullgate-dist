"""Command-line parser and entry point dispatch for Nullgate."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from nullgate import session, transports

SUBCOMMANDS = (
    "start",
    "stop",
    "status",
    "connect",
    "logs",
    "restart",
    "upgrade",
    "open",
    "shut",
    "inspect",
    "enter",
    "trace",
    "cycle",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nullgate",
        description="Disposable SSH gateway into confined directory workspaces.",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"nullgate {session._version()}",
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="command")

    start_parser = sub.add_parser(
        "start",
        aliases=["open"],
        description="Start SSH access to a workspace.",
        help="Start SSH access to a workspace (alias: open).",
    )
    start_parser.add_argument(
        "workspace",
        nargs="?",
        help="Directory to make available (default: current directory).",
    )
    start_parser.add_argument(
        "--ssh-port",
        dest="port",
        type=int,
        default=None,
        help=f"Local SSH server port (default: {session.DEFAULT_PORT}).",
    )
    start_parser.add_argument("--port", dest="port", type=int, help=argparse.SUPPRESS)
    start_parser.add_argument(
        "--tunnel-slot",
        dest="slot",
        type=int,
        default=None,
        help=f"srv.us tunnel slot (default: {session.DEFAULT_SLOT}).",
    )
    start_parser.add_argument("--slot", dest="slot", type=int, help=argparse.SUPPRESS)
    start_parser.add_argument(
        "--provider",
        dest="transport",
        choices=transports.VALID_TRANSPORTS,
        default=None,
        help=f"Public connection provider (default: {transports.DEFAULT_TRANSPORT}).",
    )
    start_parser.add_argument(
        "--transport",
        dest="transport",
        choices=transports.VALID_TRANSPORTS,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--public-access",
        dest="accept",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Allow connections without SSH credentials (unsafe on public endpoints).",
    )
    start_parser.add_argument(
        "--accept",
        dest="accept",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--tcp-forwarding",
        dest="allow_tcp_forwarding",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Allow SSH port forwarding.",
    )
    start_parser.add_argument(
        "--allow-tcp-forwarding",
        dest="allow_tcp_forwarding",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--restrict-file-transfer",
        dest="confine_sftp",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Keep SFTP and SCP transfers inside the workspace.",
    )
    start_parser.add_argument(
        "--confine-sftp",
        dest="confine_sftp",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--relay-url",
        dest="endpoint",
        help="WebSocket relay URL (for upterm or cloudflare providers).",
    )
    start_parser.add_argument("--endpoint", dest="endpoint", help=argparse.SUPPRESS)
    start_parser.add_argument(
        "--public-hostname",
        dest="hostname",
        help="Public hostname (for the cloudflared provider).",
    )
    start_parser.add_argument("--hostname", dest="hostname", help=argparse.SUPPRESS)
    start_parser.add_argument(
        "--cloudflare-token",
        dest="token",
        help="Cloudflare tunnel token (for the cloudflared provider).",
    )
    start_parser.add_argument("--token", dest="token", help=argparse.SUPPRESS)

    sub.add_parser(
        "stop",
        aliases=["shut"],
        description="Stop SSH access and its connection provider.",
        help="Stop SSH access (alias: shut).",
    )

    sub.add_parser(
        "status",
        aliases=["inspect"],
        description="Show service health, connection details, and security settings.",
        help="Show current status (alias: inspect).",
    )

    sub.add_parser(
        "connect",
        aliases=["enter"],
        description="Show how to connect with SSH.",
        help="Show SSH connection instructions (alias: enter).",
    )

    logs_parser = sub.add_parser(
        "logs",
        aliases=["trace"],
        description="View or follow service logs.",
        help="View or follow service logs (alias: trace).",
    )
    logs_parser.add_argument(
        "target",
        nargs="?",
        default="all",
        choices=["all", "gateway", "transport"],
        help="Target log stream to inspect (default all).",
    )
    logs_parser.add_argument(
        "-f",
        "--follow",
        dest="f",
        action="store_true",
        help="Follow log stream output continuously.",
    )

    sub.add_parser(
        "restart",
        aliases=["cycle"],
        description="Restart SSH access using the saved settings.",
        help="Restart using saved settings (alias: cycle).",
    )

    upgrade_parser = sub.add_parser(
        "upgrade",
        description="Fetch and install latest Nullgate release.",
        help="Fetch and install latest Nullgate release.",
    )
    upgrade_parser.add_argument(
        "--version",
        help="Install a specific published version instead of the latest stable release.",
    )

    proxy_parser = sub.add_parser(
        "proxy",
        description=argparse.SUPPRESS,
    )
    proxy_parser.add_argument("url")

    upterm_proxy = sub.add_parser(
        "upterm-proxy",
        description=argparse.SUPPRESS,
    )
    upterm_proxy.add_argument("url")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    handlers = {
        "start": session.cmd_open,
        "open": session.cmd_open,
        "stop": session.cmd_shut,
        "shut": session.cmd_shut,
        "status": session.cmd_inspect,
        "inspect": session.cmd_inspect,
        "connect": session.cmd_enter,
        "enter": session.cmd_enter,
        "logs": session.cmd_trace,
        "trace": session.cmd_trace,
        "restart": session.cmd_cycle,
        "cycle": session.cmd_cycle,
        "upgrade": session.cmd_upgrade,
        "proxy": transports.cmd_proxy,
        "upterm-proxy": transports.cmd_upterm_proxy,
    }

    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help(sys.stderr)
        return 2
    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
